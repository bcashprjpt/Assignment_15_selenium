
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
# Correct path to your chromedriver executable
chrome_driver_path = 'C:/Program Files (x86)/Google/chromedriver.exe'
service = Service(executable_path=chrome_driver_path)

driver = webdriver.Chrome(service=service)
driver.get('http://www.google.com')

input_serach =  driver.find_element(By.NAME,'q')
input_serach.send_keys('selenium',Keys.RETURN)
time .sleep(20)

#button = driver.find_element(By.NAME,'btnK')
#button.click()
driver.back()
time .sleep(20)
driver.forward()
time .sleep(20)

driver.quit()