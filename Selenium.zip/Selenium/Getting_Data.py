from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()
driver.get('https://www.amazon.in/')
driver.maximize_window()

driver.find_element(By.XPATH,"//input[@id='twotabsearchtextbox']").send_keys('iphone')

driver.find_element(By.XPATH,"//input[@id= 'nav-search-submit-button']").click()

time.sleep(10)
product_titles = driver.find_elements(By.XPATH, "//h2[@class='a-size-medium a-spacing-none a-color-base a-text-normal']/span")
product_prices = driver.find_elements(By.XPATH, "//span[@class='a-price-whole']")
#print(str(len(product_prices)))
#print(str(len(product_titles)))


for i in range(min(len(product_titles), len(product_prices))):
    title = product_titles[i].text
    price = product_prices[i].text
    print(f"{i+1}. {title} - ₹{price}")



