from selenium import webdriver
import time
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.get('https://www.amazon.in/')
driver.maximize_window()

time.sleep(10)

select_1 = driver.find_element(By.LINK_TEXT,'Bestsellers')
select_1.click()
time.sleep(5)

select_2 = driver.find_element(By.LINK_TEXT,'Books')
select_2.click()
time.sleep(5)


select_3 = driver.find_element(By.LINK_TEXT,'Engineering')
select_3.click()
time.sleep(5)
