from selenium import webdriver
import time
from selenium.webdriver.common.by import By


driver = webdriver.Chrome()
driver.get('https://www.boat-lifestyle.com/')
driver.maximize_window()

time.sleep(5)
driver.refresh()
time.sleep(10)
driver.quit()